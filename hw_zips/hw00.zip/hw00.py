#Problem 1
def add(x,y):
	"""return the sum of x and y."""
	"***YOUR CODE HERE ***"

def sub(x,y):
	"""return the value of x minus y"""
	"***YOUR CODE HERE***"

def mul(x,y):
	"""return the value of x times y"""
	"***YOUR CODE HERE***"

def div(x,y):
	"""return x divided by y"""
	"***YOUR CODE HERE***"

#Problem 2
def quick_math_one(x,y):
	"""Using the arithmetic functions you just made, compute
	((4+(4*6))*(3+5))
	"""

def quick_math_two(x,y):
	"""Using the arithmetic functions you just made, compute
	((5*(4/2))*((84/4)+9))
	"""
#Problem 3
def a_plus_abs_b(a,b):
	"""Return a+abs(b), but without calling abs.
	>>> a_plus_abs_b(2,3)
	5
	>>> a_plus_abs_b(2,-3)
	5
	"""
#Problem 4
def two_of_three(a,b,c):
	"""Return x*x + y*y, where x and y are the two largest numbers of the 
	positive numbers a,b, and c.
	>>>two_of_three(1,2,3)
	13
	>>>two_of_three(5,3,1)
	34
	>>>two_of_three(10,2,8)
	164
	>>>two_of_three(5,5,5)
	50
	"""
	"***YOUR CODE HERE***"
#Problem 5
def if_function(condition, true_result, false_result):
	"""Return true_result if condition is a true value, and false_result otherwise."""
	"***YOUR CODE HERE***"


